package masina;

public interface Operacija {
       void izvrsi(Stek s);
}
