package masina;

public class Sabiranje implements Operacija{
	
	@Override
	public void izvrsi(Stek s) {
		int x=s.ukloni();
		int y=s.ukloni();
		s.dodaj(x+y);
	}

}
