package masina;

public class Dodavanje implements Operacija{
	
	private int broj;
	
	public Dodavanje(int br){
		broj=br;
	}
  
	@Override
	public void izvrsi(Stek s) {
		s.dodaj(broj);
	}
}
