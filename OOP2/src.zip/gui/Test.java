package gui;

import java.awt.Frame;

public class Test {

	public static void main(String[] args) {
		Frame frame = new Frame();
		
		frame.setResizable(false);
		
		frame.setBounds(700, 200, 400, 300);
		
		frame.setTitle("Basic window");
		
		frame.setVisible(true);
	}

}
