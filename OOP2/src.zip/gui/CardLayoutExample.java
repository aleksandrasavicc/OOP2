package gui;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class CardLayoutExample extends Frame {
	
	private static final int cardsCount = 5;
	
	private void populateWindow() {
		
		CardLayout cardLayout = new CardLayout();
		Panel cardPanel = new Panel(cardLayout);
		
		Panel card;
		for(int i = 0; i < cardsCount; i++) {
			card = new Panel();
			card.setBackground(new Color((float)Math.random(), (float)Math.random(), (float)Math.random()));
			cardPanel.add(card);
		}
		
		add(cardPanel, BorderLayout.CENTER);
		
		Button next = new Button("-> Next"), previous = new Button("Previous <-");
		
		next.addActionListener((ae) -> {
			cardLayout.next(cardPanel);
		});
		
		previous.addActionListener((ae) -> {
			cardLayout.previous(cardPanel);
		});
		
		Panel southPanel = new Panel();
		southPanel.add(previous);
		southPanel.add(next);
		add(southPanel, BorderLayout.SOUTH);
		
	}
	
	public CardLayoutExample() {
		setTitle("Cards");
		
		populateWindow();
		
		setBounds(700, 200, 400, 300);
		
		addWindowListener(new WindowAdapter() {
			
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
		
		setResizable(false);
		setVisible(true);
	}

	public static void main(String[] args) {
		new CardLayoutExample();
	}

}
