package l3v1;

import java.awt.Color;

public abstract class Nebesko_telo extends Objekat {
    
	protected int r;
	
	public Nebesko_telo(int a, int b, Color c, int r) {
		super(a,b,c);
		this.r=r;
	}
	
	public int getX(double angle) {
		return (int)(r * Math.cos(angle));
	}

	
	public int getY(double angle) {
		return (int)(r * Math.sin(angle));
	}

}
