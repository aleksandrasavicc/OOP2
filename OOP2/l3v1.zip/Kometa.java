package l3v1;

import java.awt.Color;
import java.awt.Graphics;

public class Kometa extends Nebesko_telo {
	
	private double startangle=Math.random();
   
	public Kometa(int a, int b, int r) { //ne stvara se sa bojom
		super(a,b,Color.GRAY,r);
	}
	
	@Override 
	public void paint(Graphics g) {
		
        //g.translate(this.x, this.y); //nisam sigurna da li treba, ovo mi je za pomeranje centra
		g.setColor(Color.GRAY);
		double inc = 2 * Math.PI / 5;
		int xTacke[]=new int[5];
		int yTacke[]=new int[5];
		int i=0;
		for(double angle = 0; angle < 2 * Math.PI; angle += inc) {
			xTacke[i] = this.getX(angle+startangle)+this.x;
			yTacke[i] = this.getY(angle+startangle)+this.y;
			i++;
		}
       g.fillPolygon(xTacke, yTacke, 5 );
 
	}
	
	
	

}
