package l3v1;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Simulator extends Frame{
	
	private Button pokreni = new Button("Pokreni!");
	private Svemir svemir=new Svemir();
	private Generator generator=new Generator(svemir);
	private Panel buttonPanel; 
	public Simulator() {
		
		setBounds(700,200,200,400); 
		setResizable(false);
		
		populateWindow();

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				
				dispose();
				svemir.finish();
				generator.finish();
			}
		});
		
		setVisible(true);
	}

	public void populateWindow() {
		
	   buttonPanel=new Panel();
	   svemir.setBackground(Color.BLACK);
	   add(svemir, BorderLayout.CENTER);
	   buttonPanel.add(pokreni);
	   add(buttonPanel,BorderLayout.SOUTH);
	   
	   pokreni.addActionListener((ae)->{
		    svemir.pokreni();
		    generator.pokreni();
			pokreni.setEnabled(false);
	   });
		
	}

	public static void main(String[] args) {
		new Simulator();

	}

} 
