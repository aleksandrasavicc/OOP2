package l3v1;

public class Generator implements Runnable {
	
    private Svemir svemir;
    private Thread thread = new Thread(this);
    private long sleepTime = 900;
    private boolean radi;
    
    public Generator(Svemir svemir) {
    	this.svemir = svemir;	
    }

	@Override
	public void run() {
		
		try {
			while(!Thread.interrupted()) {
				synchronized (this) {
				  while(!radi) wait();
				}
				Thread.sleep(sleepTime);
				
			    int x = (int) (Math.random()*200);
			    int r = (int) ((Math.random() * (30 - 10)) + 10);
			    Kometa k=new Kometa(x,0,r);
			    svemir.dodajTelo(k);
			}	
		} catch (InterruptedException e) {}
		
	}
	
	public synchronized void pokreni() {
		thread.start();
		radi=true;
		notify();
	}
	
	public synchronized void finish() { //ovo jos jednom proveri
		radi=false;
		thread.interrupt();
		
		/*while (thread != null) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}*/
	}
    
    
}
