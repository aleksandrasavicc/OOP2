package l3v1;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

public class Svemir extends Canvas implements Runnable{
     
	private ArrayList<Nebesko_telo> nebtela = new ArrayList<>();
	private long sleepTime = 100;
	private Thread thread = new Thread(this);
	private boolean radi;
	
	public Svemir() {
		
		this.setBackground(Color.BLACK);
	}
	
	public void dodajTelo(Nebesko_telo t) {
		nebtela.add(t);
	}

	@Override
	public void run() {
		try {
			while(!Thread.interrupted()) {
				synchronized (this) {
					while(!radi)
						wait();
				}
				
			Thread.sleep(sleepTime);
			repaint();
			}
			}catch (InterruptedException e) {}
	}
	
	
	@Override
	public void paint(Graphics g) {
		
		for(int i=0;i<nebtela.size();i++) {
			nebtela.get(i).paint(getGraphics());
			nebtela.get(i).promeniY(5);
		}
		
	}
	
	public synchronized void pokreni() {
		
		thread.start();
		radi = true;
		notify();
		
	}
	
	public synchronized void finish() { 
		    radi=false;
		    thread.interrupt();
		/*if(thread != null) {
			thread.interrupt();
		}
		while (thread != null) {
			try {
				wait();
			} catch (InterruptedException e) {}
		}*/
	}
	
	
	
}
