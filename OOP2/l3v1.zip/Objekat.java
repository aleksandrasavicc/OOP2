package l3v1;

import java.awt.Color;
import java.awt.Graphics;

public abstract class Objekat {
      
	protected int x,y;
	protected Color color;
	
	public Objekat(int a, int b,Color c) {
		x=a;
		y=b;
	    color=c;
	}

	public void promeniX(int x) {
		this.x += x;
	}

	public void promeniY(int y) {
		this.y += y;
	}
    
	public abstract void paint(Graphics g);
   
	
}
