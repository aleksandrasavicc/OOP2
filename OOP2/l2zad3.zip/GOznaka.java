package skijanje;

public class GOznaka extends Exception {

}
