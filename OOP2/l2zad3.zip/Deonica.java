package skijanje;

public abstract class Deonica {
     protected double duzina;
     protected double nagib;
     public Deonica(double d, double n) {
    	 duzina=d;
    	 nagib=n;
     }
     
     public double duzina() {
    	 return duzina;
     }
     
     public double nagib() {
    	 return nagib;
     }
     
     public abstract char oznaka();
     public abstract double ubrzanje();
     
     public double brzina(double pocetna) {
    	 return Math.sqrt(2*ubrzanje()*duzina()+Math.pow(pocetna, 2));
     }
     
     public double vreme(double pocetna) {
    	 return (this.brzina(pocetna)-pocetna)/ubrzanje();
     }

	@Override
	public String toString() {
		return oznaka() + "(" + String.format("%.1f", duzina()) + "," + String.format("%.1f", nagib()) + ")";
	} 
     
}
