package skijanje;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class Staza {
	
	private List<Deonica>deonice=new ArrayList<>();
	HashMap<Character, Integer> mapa = new HashMap<>();
	private String naziv;
	
	public Staza(String n) {
		naziv=n;
	}

	public void dodaj(Deonica deo1) {
		deonice.add(deo1);
	}

	public int broj() {
		return deonice.size();
	}
	
	public double duzina() {
		double s=0;
		for(Deonica d:deonice) {
			s+= d.duzina();
		}
		return s;
	}
	
	public double nagib(){ 
		double max=0;
		for(Deonica d:deonice) {
			if(max<d.nagib())
			     max=d.nagib();
		}
		return max;
	}
	
	public char oznaka()throws GOznaka{
		if(deonice.isEmpty()) throw new GOznaka();
		int i=1;
		for(Deonica d:deonice) {
			    mapa.put(d.oznaka(),i++);
		}
		int max=0;
		char m=deonice.get(0).oznaka();
		for(Deonica d:deonice) {
			if(mapa.get(d.oznaka())>max) {
				max=mapa.get(d.oznaka());
				m=d.oznaka();
			}
		}
		/*int k=0;
		for(Deonica d:deonice) {
			if(mapa.get(d.oznaka())==max){
				k++;
				if(k==2) return deonice.get(0).oznaka();
			}
			}*/
			return m;
		}
		
	public double brzina(double pocetna) {
		double v=pocetna;
		for(Deonica d:deonice) {
			v=d.brzina(v);
		}
		return v;
	}
	
	public double vreme(double pocetna) {
		double t=0;
		double v=pocetna;
		for(Deonica d:deonice) {
			t+=d.vreme(v);
			v=d.brzina(v);
		}
		return t;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(naziv);builder.append("|");
		builder.append(broj());builder.append("|");
		builder.append(duzina());builder.append("|");
		builder.append(nagib()); builder.append("\n[");
		int i=0;
		for(Deonica d:deonice) {
			if(i!=0) {
			builder.append(",");
			}
			builder.append(d.toString());
			i=1;
		}
		builder.append("]");
		return builder.toString();
	}
}
