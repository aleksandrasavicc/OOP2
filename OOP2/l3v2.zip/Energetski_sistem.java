package lab3v2;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Panel;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class Energetski_sistem extends Frame {

	private Plac plac;
	private Baterija baterija;
	private int kapacitet;
	private Button dodaj = new Button("Dodaj");
	private Panel buttonPanel; 
	public static int id2=0;
	
	public Energetski_sistem(int r, int k, int kap) {
		
		setBounds(500, 100, 500, 500); 
		setTitle("Energetski sistem");
		setResizable(false);
		plac = new Plac(k,r);
		kapacitet=kap;
		baterija= new Baterija(kap);
		setVisible(true);
		add(plac);
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				
				plac.zavrsiProizvodjace();
				dispose();
				
			}
		});
		
		buttonPanel=new Panel();
		buttonPanel.add(dodaj);
		add(buttonPanel,BorderLayout.NORTH);
		   
	    dodaj.addActionListener((ae)->{
			    plac.dodajProizvodjaca(new Hidroelektrana(baterija));
			    revalidate();
	   
		   });
		
		
		setVisible(true);
	}
	
	
	public static void main(String[] args) {
		new Energetski_sistem(5,5,100);
	}

	
}
