package lab3v2;

import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Font;
import java.awt.GraphicsConfiguration;
import java.awt.GridLayout;
import java.awt.HeadlessException;


public class Plac extends Panel {
	
	private int kolone;
	private int redovi;
	private Parcela resetka[][];
	private Parcela izabranaParcela;
	private int x,y;
	
    public Plac(int k,int r) {
    	
    	kolone = k;
    	redovi = r;
    	resetka = new Parcela[r][k];
    	this.setLayout(new GridLayout(k,r,5,5));
    	populateWindow();
    	
    }
	
	public void populateWindow() {
		
		double r;
		for(int i=0; i<redovi; i++) {
			for(int j=0; j<kolone; j++) {
				 r = Math.random();
				if(r < 0.7) {
					resetka[i][j] = new TravPovrs();
					this.add(resetka[i][j]);
				}
				else {
					resetka[i][j] = new VodPovrs();
					this.add(resetka[i][j]);
			}
		}		
	}  
		
	
	}  
	
	public void izaberiParcelu(Parcela parcela) {
		
        if(izabranaParcela!=null)
        izabranaParcela.setFont(new Font("Serif", Font. BOLD, 14)); //staru vrati
        parcela.setFont(new Font("Serif", Font. BOLD, 20));
        izabranaParcela=parcela;
        
	}
	
	public void dodajProizvodjaca(Hidroelektrana hidroelektrana) {
		
		if(izabranaParcela instanceof Proizvodjac) {
			((Proizvodjac) izabranaParcela).zaustavi();
		}
		
		if(izabranaParcela==null) hidroelektrana.zaustavi();
		
		for(int i=0; i<redovi; i++) {
			for(int j=0; j<kolone; j++) {
				
				if(resetka[i][j]==izabranaParcela) {
				   this.remove(i*redovi+j); //skloniti staru
				   resetka[i][j]=hidroelektrana;
				   this.add(hidroelektrana, i*redovi+j);
				   revalidate();//ovde smo dohvatili i,j
				   x = i;
				   y = j;
				   break;
				}
			}
		}
		
		hidroelektrana.okruzujucePovrsi=azurirajPolja();
		izabranaParcela=null;
   }
	
	public int azurirajPolja() {
		int br=0;
		Hidroelektrana h;
		boolean v=false;
		if(izabranaParcela instanceof VodPovrs) {
			v=true;
		}
		if(izabranaParcela != null) {
			//1	  
			if(x-1>=0 && y-1>=0 && resetka[x-1][y-1] instanceof VodPovrs)
			    br++;
			   else {
			   if(x-1>=0 && y-1>=0 && resetka[x-1][y-1] instanceof Hidroelektrana && v) {
				h = (Hidroelektrana)resetka[x-1][y-1];
		        h.okruzujucePovrsi--;
			}    
		    }
			//2
			if(x-1>=0 && resetka[x-1][y] instanceof VodPovrs)
			    br++;
			   else {
			   if(x-1>=0 && resetka[x-1][y] instanceof Hidroelektrana && v) {
				h = (Hidroelektrana) resetka[x-1][y];
	            h.okruzujucePovrsi--;
			   }    
		       }
			//3
			if(x-1>=0 && y+1<=kolone-1 && resetka[x-1][y+1] instanceof VodPovrs)
			    br++;
			   else {
			   if(x-1>=0 && y+1<=kolone-1 && resetka[x-1][y+1] instanceof Hidroelektrana && v) {
				h = (Hidroelektrana) resetka[x-1][y+1];
	            h.okruzujucePovrsi--;	
			   }
		    }
			//4
			if(y-1>=0 && resetka[x][y-1] instanceof VodPovrs)
			    br++;
			   else {
			if(y-1>=0 && resetka[x][y-1] instanceof Hidroelektrana && v) {
				h = (Hidroelektrana) resetka[x][y-1];
	            h.okruzujucePovrsi--;
			}
		    }
			//5
			if(y+1<=kolone-1 && resetka[x][y+1] instanceof VodPovrs)
		       br++;
		       else {
		    if(y+1<=kolone-1 &&resetka[x][y+1] instanceof Hidroelektrana && v) {
		    	h = (Hidroelektrana) resetka[x][y+1];
	            h.okruzujucePovrsi--;
	        }
		       }
			//6
			if(x+1<=redovi-1 && y-1>=0 && resetka[x+1][y-1] instanceof VodPovrs)
		       br++;
		       else {
		    if(x+1<=redovi-1 && y-1>=0 && resetka[x+1][y-1] instanceof Hidroelektrana && v) {
		    	h = (Hidroelektrana) resetka[x+1][y-1];
	            h.okruzujucePovrsi--;
	        }
		       }
			//7
			if(x+1<=redovi-1 && resetka[x+1][y] instanceof VodPovrs)
		       br++;
		       else {
		    if(x+1<=redovi-1 && resetka[x+1][y] instanceof Hidroelektrana && v) {
		    	h = (Hidroelektrana) resetka[x+1][y];
	            h.okruzujucePovrsi--;
	        }
		       }
			//8
			if(x+1<=redovi-1 && y+1<=kolone-1 && resetka[x+1][y+1] instanceof VodPovrs)
		       br++;
		       else {
		    if(x+1<=redovi-1 && y+1<=kolone-1 && resetka[x+1][y+1] instanceof Hidroelektrana && v) {
		    	h = (Hidroelektrana) resetka[x+1][y+1];
	            h.okruzujucePovrsi--;
	        }
		       }
        }
		
		return br;
	}
	   
    public void zavrsiProizvodjace() {
	//prodji kroz sve proizvodjace i pozovi zavrsi
		for(int i=0; i<redovi; i++) {
			for(int j=0; j<kolone; j++) {
	
			    if(resetka[i][j] instanceof Proizvodjac) {
			 
			    	((Proizvodjac)resetka[i][j]).zaustavi();
				}
			}
		} 
    }
 
}
	
	

