package lab3v2;

import java.awt.Color;

public class Hidroelektrana extends Proizvodjac {
	
	int okruzujucePovrsi;

	public Hidroelektrana(Baterija bat) {
		super('H', Color.BLUE, 1500, bat);
		okruzujucePovrsi=0; 
		
	}
	
    
	@Override
	public synchronized boolean proizvedi() {
		
		if(okruzujucePovrsi!=0) {
		    baterija.dodajEnergiju(okruzujucePovrsi);
		 	return true;
		}
		else
			return false;
	}

}
