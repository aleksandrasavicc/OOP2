package lab3v2;

import java.awt.Color;
import java.util.Random;

public abstract class Proizvodjac extends Parcela implements Runnable{
	
	private int vreme;
	protected Baterija baterija;
	private Thread nit=new Thread(this);
	private boolean radi=true;
	protected int sleepTime=300;
   
	public Proizvodjac(char o, Color b, int v, Baterija bat) {
		
		super(o,b);
		vreme = v;
		baterija = bat;
		nit.start();
	}
	
	public int ukupnoVreme() {
		
		return vreme + new Random().nextInt(301);
	}
	
	@Override
	public void run() {
		try {
			while(!Thread.interrupted()) {
				synchronized (this) {
					while(!radi)
						wait();
				}
			  Thread.sleep(ukupnoVreme());	
			  if(proizvedi()) { 
				 this.setForeground(Color.RED); 
				 Thread.sleep(sleepTime);		
				 revalidate();
				 this.setForeground(Color.WHITE);
				 revalidate();
			}
			}
			}catch (InterruptedException e) {}
	}
	
	public abstract boolean proizvedi();
	
	public synchronized void zaustavi() {
	    radi=false;
	    nit.interrupt();
	}
	
}
