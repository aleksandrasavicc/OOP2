package lab3v2;

import java.awt.Color;

public class TravPovrs extends Parcela {
	
	public TravPovrs() {
		super('"',Color.GREEN);
	}

}
