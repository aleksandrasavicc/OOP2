package lab3v2;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Label;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;

public class Parcela extends Label {
    
	protected Color boja;
	protected char oznaka;
	
	public Parcela(char o, Color b) {
		
		super(((Character)o).toString(),Label.CENTER);
		oznaka = o;
		boja = b;
		this.setBackground(b);
		populateWindow();
		
	}
	
	
	public void promeniPozadinu(Color b) {
		boja=b;
	}
	
	public void populateWindow() {
		
		this.setText(((Character)oznaka).toString());
		this.setForeground(Color.WHITE);
		this.setFont(new Font("Serif", Font.BOLD, 14));
		
		this.addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent e) {
                 
            	((Plac) getParent()).izaberiParcelu((Parcela)e.getSource());
            	
            }
        });
	}
    
   
	
	
	
}
