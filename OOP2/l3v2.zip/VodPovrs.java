package lab3v2;

import java.awt.Color;

public class VodPovrs extends Parcela {
	
	public VodPovrs() {
		super('~',Color.CYAN);
	}
}
