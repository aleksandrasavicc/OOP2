package lab3v2;

public class Baterija {
	
	int energija;
	int maxkap;
	
	public Baterija(int mk) {
		
		maxkap = mk;
		energija = mk; 
	}
    
	public synchronized void dodajEnergiju(int x){
		
		energija += x;
		if(energija> maxkap) energija=maxkap;
	}
	
	public synchronized void isprazni() {
		
		energija=0;
	}
	
	public synchronized boolean puna() {
		
		return energija == maxkap;
	}
	
	
	
}
