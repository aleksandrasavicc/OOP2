package banditi;

public class GNepostojeciVagon extends Exception {
       
}