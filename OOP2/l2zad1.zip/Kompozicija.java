package banditi;

import java.util.ArrayList;
import java.util.List;

public class Kompozicija {
    
     private List<Vagon>vagoni=new ArrayList<>();
     //public enum Smer{ISPRED,IZA};
     //private Smer smer;

	public void dodajVagon(Vagon vagon2) {
		vagoni.add(vagon2);
	}
    
	public Vagon dohvatiVagon(Bandit bandit) throws GNepostojeciVagon{
		for(int i=0;i<vagoni.size();i++) {
			for(int j=0;j<vagoni.get(i).dohvatiBrojBandita();j++) {
				if(vagoni.get(i).dohvatiBandita(j)==bandit) { //kako ih poredi
					return vagoni.get(i);
				}
			}
		}
		throw new GNepostojeciVagon();
	}
	
	public Vagon dohvatiSusedniVagon(Vagon v,Smer s) throws GNepostojeciVagon{
		int i=vagoni.indexOf(v);
		if(s.toString()=="ISPRED" && i>0) {
			return vagoni.get(i-1);
		} else if(s.toString()=="IZA"&& i<vagoni.size()-1) 
			return vagoni.get(i+1);	
		throw new GNepostojeciVagon();
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		int i=0;
		for(Vagon v:vagoni) {
				if(i!=0) {
					sb.append('_');
				}
				sb.append(v.toString());
				i=1;
			}
		return sb.toString();
		
	} 
     

     
}
