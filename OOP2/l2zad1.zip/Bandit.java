package banditi;

public class Bandit {
        
	private int zlatnici;
	public static enum Tim{A,B};
	public Tim tim;
	
	public Bandit(Tim tim) {
		zlatnici=50;
		this.tim=tim;
	}
	
	public Tim dohvatiTim()
	{
		return tim;
	}
	
	public int dohvatiBrojZlatnika() {
		return zlatnici;
	}

	public void promeniBrojZlatnika(int i) {
		this.zlatnici+=i;
	}
	

	@Override
	public String toString() {
		String s=dohvatiTim().toString()+dohvatiBrojZlatnika();
		return s;
	}
    
	
}
