package banditi;

import java.util.ArrayList;
import java.util.List;

public class Vagon {
	
	private List<Bandit>banditi=new ArrayList<>();

	public void dodajBandita(Bandit bandit) {
	 banditi.add(bandit);
	}

	public int dohvatiBrojBandita() {
		return banditi.size();
	}

	public Bandit dohvatiBandita(int i) {
		return banditi.get(i);
	}

	public boolean sadrziBandita(Bandit dohvatiBandita) {
		return banditi.contains(dohvatiBandita);
	}

	public Bandit ukloniBandita(Bandit dohvatiBandita) {
		banditi.remove(dohvatiBandita);
		return dohvatiBandita;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		int i=0;
		for(Bandit b:banditi) {
			if(i!=0) {
				builder.append(',');
			}
			builder.append(b.toString());
			i=1;
		}
		builder.append("]");
		return builder.toString();
	}
	
}
