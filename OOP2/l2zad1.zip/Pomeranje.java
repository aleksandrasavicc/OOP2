package banditi;

public class Pomeranje extends Akcija {
	
	private Smer smer;
	public Pomeranje(Kompozicija k,Smer s) {
		super(k);
		this.smer=s;
		
	}

	@Override
	public void izvrsi(Bandit b) {
		try {
		Vagon v=k.dohvatiVagon(b);
		Vagon susedni=k.dohvatiSusedniVagon(v, smer);
		v.ukloniBandita(b);
		susedni.dodajBandita(b);
	}catch(GNepostojeciVagon g) {
		
	}
	}

	@Override
	public String toString() {
		return "Pomeranje : "+smer.toString();
	}
	
}
