package revija;

public class Kombinacija {
	
	private int n;
	private int next=0;
	private  Nosivo niz[];
	public Kombinacija(int k){
		n=k;
		niz=new Nosivo[k];
	}
	
	public void dodaj(Nosivo s) throws GDodavanje {
		if(next==n)
			throw new GDodavanje();
		niz[next++]=s;
	}

	public int dohvBrStvari() {
		return next;
	}

	public int dohvMaxBrStvari() {
		return n;
	}

	public Nosivo dohvStvar(int i) throws GIndeks{
		if(i<0 ||i>next) {
			throw new GIndeks();
		}
	   return niz[i];
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("[");
		for(int i=0;i<next;i++) {
			if(i!=0) {
				builder.append(",");
			}
			builder.append(niz[i].toString());
			}
		builder.append("]");
		return builder.toString();
	}
	
}
