package revija;

public class GDodavanje extends Exception {

}
