package revija;

public class Model {
   
	 private Velicina velicina;
	 private static int ID=0;
	 private int id=ID++;
	 public Model(Velicina v) {
		  this.velicina=v;
	  }
	public int dohvId() {
		return id;
	}
	public Velicina dohvVelicinu() {
		return velicina;
	}
	@Override
	public String toString() {
	  return "Model " +id+ " ("+velicina.toString()+ ")";
	  }
}
