package revija;

public class Velicina {
 
	 public static enum Oznaka{S,M,L};
     private Oznaka oznaka;
     
     public Velicina(Oznaka o){
   	  oznaka=o;
     }

	public Oznaka dohvOznaku() {
		return oznaka;
	}
    
	@Override
	public String toString() {
		return oznaka.toString();
	}
	

	public boolean manja(Velicina v) {
		return this.oznaka.ordinal()<v.oznaka.ordinal();
	}
      
}
