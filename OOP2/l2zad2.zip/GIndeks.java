package revija;

public class GIndeks extends Exception {

}
