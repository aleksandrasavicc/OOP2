package revija;

public interface Nosivo {
    boolean odgovara(Model m);
    //String toString();
}
